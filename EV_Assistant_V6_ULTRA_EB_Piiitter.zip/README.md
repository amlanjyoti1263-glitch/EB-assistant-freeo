# EV Assistant V5.1 EB

Online, non-AI voice assistant for Android 10+.

Features: EV mode, Personal Assistant mode, rule/context conversation engine, public online knowledge lookup, Hindi live weather, native Android TTS/SpeechRecognizer, offline music, radio streams, live face/eye display.

Build with GitHub Actions using `.github/workflows/main.yml` or the included build workflow.
