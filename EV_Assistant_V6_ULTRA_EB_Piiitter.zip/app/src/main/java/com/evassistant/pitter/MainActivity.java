package com.evassistant.pitter;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import android.media.AudioAttributes;
import android.media.MediaPlayer;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_RECORD_AUDIO = 1001;
    private static final int REQ_AUDIO_FILE = 2001;
    private static final int REQ_LOCATION = 3001;
    private android.webkit.GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;

    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean speechReady = false;
    private boolean listeningWanted = false;
    private boolean permissionRequestPending = false;
    private boolean webReady = false;
    private boolean permissionDenied = false;
    private String pendingSpeechText = null;
    private ValueCallback<Uri[]> fileChooserCallback;
    private boolean recognitionActive = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicInteger utteranceCounter = new AtomicInteger();
    private MediaPlayer radioPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback) {
                geoOrigin = origin; geoCallback = callback;
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = filePathCallback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("audio/*");
                    startActivityForResult(intent, REQ_AUDIO_FILE);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                webReady = true;
                if (permissionDenied) {
                    callJs("window.onNativeMicPermissionDenied && window.onNativeMicPermissionDenied();");
                } else if (hasRecordAudioPermission()) {
                    callJs("window.onNativeMicPermissionGranted && window.onNativeMicPermissionGranted();");
                }
            }
        });
        webView.addJavascriptInterface(new AndroidVoiceBridge(), "AndroidVoice");

        initTextToSpeech();
        initSpeechRecognizer();
        webView.loadUrl("file:///android_asset/index.html");

        // Native request: this is independent of WebView/JavaScript startup.
        handler.postDelayed(this::ensureMicrophonePermission, 350);
    }

    private boolean hasRecordAudioPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureMicrophonePermission() {
        if (hasRecordAudioPermission()) {
            permissionDenied = false;
            if (webReady) {
                callJs("window.onNativeMicPermissionGranted && window.onNativeMicPermissionGranted();");
            }
            return;
        }
        permissionDenied = false;
        permissionRequestPending = true;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
    }

    private void openMicrophoneSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void initTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(new Locale("hi", "IN"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech.setLanguage(Locale.US);
                }
                textToSpeech.setSpeechRate(1.0f);
                textToSpeech.setPitch(1.08f);
                speechReady = true;
                callJs("window.onNativeTTSReady && window.onNativeTTSReady();");
                if (pendingSpeechText != null) {
                    String pending = pendingSpeechText;
                    pendingSpeechText = null;
                    speakNow(pending);
                }
            }
        });

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
            textToSpeech.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }

                @Override public void onDone(String utteranceId) {
                    runOnUiThread(() -> callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();"));
                }

                @Override public void onError(String utteranceId) {
                    runOnUiThread(() -> callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();"));
                }
            });
        }
    }

    private void initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                recognitionActive = true;
                callJs("window.onNativeSpeechReady && window.onNativeSpeechReady();");
            }

            @Override public void onBeginningOfSpeech() {
                recognitionActive = true;
                callJs("window.onNativeSpeechStarted && window.onNativeSpeechStarted();");
            }

            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }

            @Override public void onEndOfSpeech() {
                callJs("window.onNativeSpeechEnded && window.onNativeSpeechEnded();");
            }

            @Override public void onError(int error) {
                recognitionActive = false;
                if (!listeningWanted) return;
                String message = "Speech error " + error;
                callJs("window.onNativeSpeechError && window.onNativeSpeechError(" + quote(message) + ");");
                // Restart is owned by the JavaScript voice lifecycle. Keeping a
                // single restart owner prevents Android + JS from fighting each other.
            }

            @Override public void onResults(Bundle results) {
                recognitionActive = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                listeningWanted = false;
                if (!text.trim().isEmpty()) {
                    callJs("window.onNativeSpeechFinal && window.onNativeSpeechFinal(" + quote(text) + ");");
                } else {
                    callJs("window.onNativeSpeechError && window.onNativeSpeechError('No speech detected');");
                }
            }

            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    callJs("window.onNativeSpeechPartial && window.onNativeSpeechPartial(" + quote(matches.get(0)) + ");");
                }
            }

            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startNativeRecognition() {
        if (speechRecognizer == null) {
            callJs("window.onNativeSpeechError && window.onNativeSpeechError('Speech recognition is unavailable on this device');");
            return;
        }
        if (!hasRecordAudioPermission()) {
            listeningWanted = true;
            ensureMicrophonePermission();
            return;
        }

        // Do not cancel here. A cancel can emit ERROR_CLIENT and create a
        // second restart cycle. Each new session is started only after the
        // previous session has ended with results or an error.
        if (recognitionActive) return;

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        try {
            recognitionActive = true;
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            recognitionActive = false;
            callJs("window.onNativeSpeechError && window.onNativeSpeechError(" + quote(e.getMessage() == null ? "Unable to start microphone" : e.getMessage()) + ");");
        }
    }

    private void stopNativeRecognition() {
        listeningWanted = false;
        recognitionActive = false;
        if (speechRecognizer != null) {
            try { speechRecognizer.stopListening(); } catch (Exception ignored) { }
            try { speechRecognizer.cancel(); } catch (Exception ignored) { }
        }
    }

    private void stopNativeRadio() {
        if (radioPlayer != null) {
            try { radioPlayer.stop(); } catch (Exception ignored) { }
            try { radioPlayer.reset(); } catch (Exception ignored) { }
            try { radioPlayer.release(); } catch (Exception ignored) { }
            radioPlayer = null;
        }
    }

    private void startNativeRadio(String url) {
        final String streamUrl = url == null ? "" : url.trim();
        if (streamUrl.isEmpty()) {
            callJs("window.onNativeRadioError && window.onNativeRadioError(" + quote("Radio URL missing") + ");");
            return;
        }
        stopNativeRadio();
        try {
            radioPlayer = new MediaPlayer();
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                radioPlayer.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build());
            } else {
                radioPlayer.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
            }
            radioPlayer.setOnPreparedListener(mp -> {
                try { mp.start(); } catch (Exception e) {
                    callJs("window.onNativeRadioError && window.onNativeRadioError(" + quote(e.getMessage() == null ? "Radio playback failed" : e.getMessage()) + ");");
                    return;
                }
                callJs("window.onNativeRadioPlaying && window.onNativeRadioPlaying();");
            });
            radioPlayer.setOnCompletionListener(mp -> {
                stopNativeRadio();
                callJs("window.onNativeRadioStopped && window.onNativeRadioStopped('ended');");
            });
            radioPlayer.setOnErrorListener((mp, what, extra) -> {
                stopNativeRadio();
                callJs("window.onNativeRadioError && window.onNativeRadioError(" + quote("Radio stream error (" + what + "," + extra + ")") + ");");
                return true;
            });
            radioPlayer.setDataSource(streamUrl);
            radioPlayer.prepareAsync();
        } catch (Exception e) {
            stopNativeRadio();
            callJs("window.onNativeRadioError && window.onNativeRadioError(" + quote(e.getMessage() == null ? "Unable to load radio stream" : e.getMessage()) + ");");
        }
    }

    private void callJs(String javascript) {
        if (webView == null) return;
        runOnUiThread(() -> webView.evaluateJavascript("javascript:(function(){try{" + javascript + "}catch(e){}})();", null));
    }

    private static String quote(String value) {
        if (value == null) value = "";
        return org.json.JSONObject.quote(value);
    }

    private void speakNow(String text) {
        if (textToSpeech == null || !speechReady) {
            pendingSpeechText = text == null ? "" : text;
            return;
        }
        stopNativeRecognition();
        String value = text == null ? "" : text;
        if (value.trim().isEmpty()) {
            callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();");
            return;
        }
        String utteranceId = "ev_assistant_" + utteranceCounter.incrementAndGet();
        Bundle params = new Bundle();
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId);
        int result = textToSpeech.speak(value, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        if (result == TextToSpeech.ERROR) {
            callJs("window.onNativeSpeechError && window.onNativeSpeechError(\"TTS speak failed\");");
            callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();");
        }
    }

    private class AndroidVoiceBridge {
        @JavascriptInterface public boolean isNativeVoiceAvailable() {
            return speechRecognizer != null && textToSpeech != null;
        }

        @JavascriptInterface public boolean isTTSReady() {
            return speechReady;
        }

        @JavascriptInterface public void startListening() {
            runOnUiThread(() -> {
                listeningWanted = true;
                startNativeRecognition();
            });
        }

        @JavascriptInterface public void stopListening() {
            runOnUiThread(MainActivity.this::stopNativeRecognition);
        }

        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> {
                if (!speechReady) {
                    pendingSpeechText = text == null ? "" : text;
                    return;
                }
                speakNow(text);
            });
        }

        @JavascriptInterface public void openMicrophoneSettings() {
            runOnUiThread(MainActivity.this::openMicrophoneSettings);
        }

        @JavascriptInterface public void playRadio(String url) {
            runOnUiThread(() -> startNativeRadio(url));
        }

        @JavascriptInterface public void stopRadio() {
            runOnUiThread(() -> {
                stopNativeRadio();
                callJs("window.onNativeRadioStopped && window.onNativeRadioStopped('stopped');");
            });
        }

        @JavascriptInterface public void stopSpeaking() {
            runOnUiThread(() -> {
                if (textToSpeech != null) textToSpeech.stop();
                callJs("window.onNativeSpeechDone && window.onNativeSpeechDone();");
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_AUDIO_FILE) return;
        if (fileChooserCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) results = new Uri[]{uri};
        }
        ValueCallback<Uri[]> callback = fileChooserCallback;
        fileChooserCallback = null;
        callback.onReceiveValue(results);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (geoCallback != null && geoOrigin != null) {
                boolean granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                geoCallback.invoke(geoOrigin, granted, false);
                geoCallback = null; geoOrigin = null;
            }
            return;
        }
        if (requestCode != REQ_RECORD_AUDIO) return;

        permissionRequestPending = false;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            permissionDenied = false;
            listeningWanted = true;
            if (webReady) {
                callJs("window.onNativeMicPermissionGranted && window.onNativeMicPermissionGranted();");
                startNativeRecognition();
            }
        } else {
            permissionDenied = true;
            listeningWanted = false;
            if (webReady) {
                callJs("window.onNativeMicPermissionDenied && window.onNativeMicPermissionDenied();");
            }
            Toast.makeText(this,
                    "Microphone permission deny hai. App Settings me Microphone ko Allow karein.",
                    Toast.LENGTH_LONG).show();
        }
    }


    @Override
    protected void onDestroy() {
        stopNativeRecognition();
        stopNativeRadio();
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
