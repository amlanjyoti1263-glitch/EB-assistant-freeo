EV Ultra Pro Max V34.3 - Static Web Deployment

Deploy the CONTENTS of this folder as the website root.
index.html must be at the hosting root (not inside another folder).

For Netlify/Vercel/GitHub Pages/static hosting, use index.html as the entry point.
No build command is required for this static build.


V34.7: Silent watchdog is independent of microphone recognition. 20s=Listening 1, 40s=Listening 2, 60s=Listening 3, then healthcare speech launches automatically.


Voice permission fix v1.1: RECORD_AUDIO is requested directly by MainActivity at startup, independent of WebView JavaScript. If permission is denied, Android Settings can be opened from the app's microphone flow.


V6 ULTRA defaults:
- Official assistant name: EB
- Assistant nickname: Beli
- Default user name: Piiitter
- Second preset user name: Amlan
- Third option: Add Your Own Name
- EB wake-word phonetic/weak-spelling recognition is preserved and Beli is accepted as an alias.
